# Jira Auto Ack (Android), version 1.1

A small phone app for the Pixel 8 Pro that acknowledges Jira voice alerts on your own number.
Nothing leaves the phone: no cloud service, no accounts, no internet permission.

## What it does

When the on-shift switch is on and a call arrives from a number starting with `+1`:

| Time after answering | Action |
|---|---|
| 0 s | Answers the call (microphone muted) |
| 1.0 s | Key 1: presses 3 |
| 3.0 s | Key 2: presses 0 |
| 8.3 s | Hangs up |

The keys are always pressed in the order they are written in Settings, first key first.

Every other call rings normally and is answered by you:

- numbers starting with `+91`
- any other country code
- numbers shown without a country code
- hidden numbers
- any call that arrives while you are already on another call
- every call while the switch is off

## Changes in version 1.1

- Key 3 is pressed 1 second after answering (was 5 seconds); key 0 follows 2 seconds later.
- Numbers, keys and timings can be changed in the app, under Settings. No rebuild needed.
- Call history and Contacts buttons on the main screen.
- Activity log lines are numbered: "Key 1 of 2: pressed 3", "Key 2 of 2: pressed 0".
  The log shows the newest line at the top.
- Every build is now signed with the same key, so later versions install over this one.

## Test status

- Version 1.0 was built by GitHub and installed on a Pixel 8 Pro.
- The version 1.1 logic was tested in a simulation: 36 checks, all passed.
- Version 1.1 has NOT been built with the real Android SDK or run on a phone from here.
  Test with a real Jira alert before relying on it.

## Build

Upload `JiraAutoAck.zip` to the GitHub repository (same file name, replacing the old one).
The existing build starts by itself and publishes `app-debug.apk` under Releases.

With Android Studio instead: File > Open this folder, then Run.

## Install on the phone

Version 1.0 was signed with a different key, so uninstall it first. This is needed only once.

1. Settings > Apps > Jira Auto Ack > Uninstall.
2. Switch Advanced Protection off, install `app-debug.apk`, and open the app.
3. Allow the permissions it asks for, including the call log.
4. Settings > Apps > Jira Auto Ack > three-dot menu > Allow restricted settings.
5. In the app, tap "Set as default phone app".
6. Switch Advanced Protection back on.
7. The bottom of the main screen should read "Jira Auto Ack version 1.1".

## Each shift

- Start of shift: open the app and turn on "Auto-acknowledge".
- End of shift: turn it off.

## Settings (in the app)

| Setting | Default | Meaning |
|---|---|---|
| Answer callers whose number starts with | `+1` | Use full numbers, such as `+14155551234`, to limit it to Jira's numbers |
| Never answer callers whose number starts with | `+91` | Always ring normally |
| Keys to press, in order | `30` | First key first |
| Seconds after answering before the first key | 1 | Use 0 to press immediately |
| Seconds between one key and the next | 2 | Minimum 0.5 |
| Seconds on the line after the last key | 5 | Then the app hangs up |

## Important to know

- While this is the default phone app it handles ALL your calls. Its call screen is basic:
  answer, decline, hang up, mute, speaker, hold, keypad. Google Phone features such as
  call screening and spam warnings are not available while it is the default.
- Any caller whose number starts with `+1` is auto-answered while the switch is on,
  not only Jira, unless you enter Jira's full numbers in Settings.
- Emergency calling with this app as the default phone app has not been tested.
- An auto-acknowledged alert stops escalating in Jira even though nobody has looked at it.

## Files

| File | Purpose |
|---|---|
| `AckConfig.java` | Default values, number rule and key timing |
| `CallService.java` | Receives every call; runs the auto-acknowledge sequence |
| `CallActivity.java` | Call screen for normal calls |
| `MainActivity.java` | Status, shift switch, dial pad, settings, activity log |
| `DirectoryActivity.java` | Call history and contacts |
| `CallText.java`, `CallHolder.java`, `Prefs.java`, `CallActionReceiver.java` | Helpers |
| `app/debug.keystore` | Fixed signing key so updates install over the previous version |
