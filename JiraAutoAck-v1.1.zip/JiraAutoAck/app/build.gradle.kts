plugins {
    id("com.android.application")
}

android {
    namespace = "com.sre.jiraautoack"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sre.jiraautoack"
        minSdk = 31
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // A fixed signing key, kept in the project, so that every build is signed the
    // same way and a new version installs over the old one without uninstalling.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
