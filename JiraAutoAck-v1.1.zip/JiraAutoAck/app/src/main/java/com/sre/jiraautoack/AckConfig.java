package com.sre.jiraautoack;

import java.util.ArrayList;
import java.util.List;

/**
 * Default rules and timings for the automatic acknowledgement, plus the logic that
 * applies them. The values can be changed on the phone, in the app's Settings section;
 * the constants here are only the starting values.
 */
public final class AckConfig {

    private AckConfig() {
    }

    /** A call is auto-acknowledged only if the caller's number starts with one of these. */
    public static final String DEFAULT_AUTO_ACK_PREFIXES = "+1";

    /** A call is never auto-acknowledged if the caller's number starts with one of these. */
    public static final String DEFAULT_NEVER_ACK_PREFIXES = "+91";

    /** Keys to press, in order: 3 first, then 0. */
    public static final String DEFAULT_DIGITS = "30";

    /** Wait after the call is answered, before the first key. */
    public static final long DEFAULT_WAIT_BEFORE_FIRST_KEY_MS = 1000;

    /** Time from one key press to the next. */
    public static final long DEFAULT_GAP_BETWEEN_KEYS_MS = 2000;

    /** Stay on the line after the last key so the confirmation can play, then hang up. */
    public static final long DEFAULT_HOLD_AFTER_KEYS_MS = 5000;

    /** How long each key tone is held. */
    public static final long TONE_LENGTH_MS = 300;

    public static final long MIN_GAP_MS = 500;
    public static final long MAX_WAIT_MS = 60000;

    /** Removes spaces, dashes and brackets, and turns a leading "00" into "+". */
    public static String normalize(String raw) {
        if (raw == null) {
            return "";
        }
        String s = raw.replaceAll("[^0-9+]", "");
        if (s.startsWith("00")) {
            s = "+" + s.substring(2);
        }
        return s;
    }

    /** Splits "+1, +44" or "+1 +44" into its parts. */
    public static String[] splitList(String list) {
        List<String> parts = new ArrayList<>();
        if (list != null) {
            for (String part : list.split("[,\\s]+")) {
                if (!part.isEmpty()) {
                    parts.add(part);
                }
            }
        }
        return parts.toArray(new String[0]);
    }

    /**
     * True only for numbers that start with an allowed prefix and with no blocked prefix.
     * Numbers without a country code and hidden numbers return false.
     */
    public static boolean shouldAutoAck(String rawNumber, String[] allowed, String[] never) {
        String number = normalize(rawNumber);
        if (number.isEmpty()) {
            return false;
        }
        for (String prefix : never) {
            if (number.startsWith(normalize(prefix))) {
                return false;
            }
        }
        for (String prefix : allowed) {
            String p = normalize(prefix);
            if (!p.isEmpty() && number.startsWith(p)) {
                return true;
            }
        }
        return false;
    }

    /** Keys must be 1 to 10 characters from 0-9, * and #. */
    public static boolean isValidDigits(String digits) {
        return digits != null && digits.matches("[0-9*#]{1,10}");
    }

    /** Each prefix must look like +1 or +14155551234. */
    public static boolean isValidPrefixList(String list) {
        for (String part : splitList(list)) {
            if (!part.matches("\\+[0-9]{1,15}")) {
                return false;
            }
        }
        return true;
    }

    public static final int STEP_TONE_START = 1;
    public static final int STEP_TONE_STOP = 2;
    public static final int STEP_HANG_UP = 3;

    /** One timed action, measured from the moment the call is answered. */
    public static final class Step {
        public final long atMs;
        public final int type;
        public final char digit;
        /** Position of the key in the sequence, starting at 1. */
        public final int keyNumber;

        Step(long atMs, int type, char digit, int keyNumber) {
            this.atMs = atMs;
            this.type = type;
            this.digit = digit;
            this.keyNumber = keyNumber;
        }
    }

    /**
     * Builds the timed key presses, always in the order the keys are written.
     * With the default values: 1.0 s press 3, 1.3 s release, 3.0 s press 0,
     * 3.3 s release, 8.3 s hang up.
     */
    public static List<Step> buildSchedule(String digits, long waitMs, long gapMs, long holdMs) {
        List<Step> steps = new ArrayList<>();
        long gap = Math.max(gapMs, MIN_GAP_MS);
        long tone = Math.min(TONE_LENGTH_MS, gap / 2);
        long start = Math.max(waitMs, 0);
        for (int i = 0; i < digits.length(); i++) {
            char digit = digits.charAt(i);
            if (i > 0) {
                start += gap;
            }
            steps.add(new Step(start, STEP_TONE_START, digit, i + 1));
            steps.add(new Step(start + tone, STEP_TONE_STOP, digit, i + 1));
        }
        steps.add(new Step(start + tone + Math.max(holdMs, 0), STEP_HANG_UP, ' ', 0));
        return steps;
    }
}
