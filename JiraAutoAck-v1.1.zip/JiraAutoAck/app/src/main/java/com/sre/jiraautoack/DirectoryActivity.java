package com.sre.jiraautoack;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Shows either the call history or the contact list. Tapping a row puts that number
 * into the dial pad on the main screen, ready to call.
 */
public class DirectoryActivity extends Activity {

    static final String EXTRA_MODE = "mode";
    static final String MODE_RECENTS = "recents";
    static final String MODE_CONTACTS = "contacts";

    private static final int REQUEST_PERMISSION = 1;
    private static final int MAX_ROWS = 500;

    /** One row: the text shown and the number it dials. */
    static final class Entry {
        final String label;
        final String number;

        Entry(String label, String number) {
            this.label = label;
            this.number = number;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    private boolean contactsMode;
    private TextView messageView;
    private ListView listView;
    private ArrayAdapter<Entry> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        contactsMode = MODE_CONTACTS.equals(getIntent().getStringExtra(EXTRA_MODE));
        setTitle(contactsMode ? "Contacts" : "Call history");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);
        int pad = Math.round(16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, 0);

        if (contactsMode) {
            EditText search = new EditText(this);
            search.setHint("Search contacts");
            search.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (adapter != null) {
                        adapter.getFilter().filter(s);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
            root.addView(search, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        messageView = new TextView(this);
        messageView.setTextSize(15);
        messageView.setText("Loading");
        root.addView(messageView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        listView = new ListView(this);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Entry entry = adapter == null ? null : adapter.getItem(position);
                if (entry != null && !entry.number.isEmpty()) {
                    openDialPad(entry.number);
                }
            }
        });
        root.addView(listView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        loadIfPermitted();
    }

    private String neededPermission() {
        return contactsMode ? Manifest.permission.READ_CONTACTS : Manifest.permission.READ_CALL_LOG;
    }

    private void loadIfPermitted() {
        if (checkSelfPermission(neededPermission()) == PackageManager.PERMISSION_GRANTED) {
            load();
        } else {
            messageView.setText(contactsMode
                    ? "Allow access to contacts to see them here."
                    : "Allow access to the call log to see your call history here.");
            requestPermissions(new String[]{neededPermission()}, REQUEST_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_PERMISSION && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            load();
        }
    }

    /** Reads the rows on a background thread, then shows them. */
    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Entry> entries = new ArrayList<>();
                String error = null;
                try {
                    if (contactsMode) {
                        readContacts(entries);
                    } else {
                        readCallHistory(entries);
                    }
                } catch (RuntimeException e) {
                    error = "Could not read the list: " + e.getMessage();
                }
                final String message = error != null ? error
                        : entries.isEmpty() ? (contactsMode ? "No contacts with phone numbers."
                        : "No calls yet.") : "Tap a row to put the number in the dial pad.";
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        messageView.setText(message);
                        adapter = new ArrayAdapter<>(DirectoryActivity.this,
                                android.R.layout.simple_list_item_1, entries);
                        listView.setAdapter(adapter);
                    }
                });
            }
        }).start();
    }

    private void readContacts(List<Entry> entries) {
        String[] columns = {
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };
        try (Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, columns, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC")) {
            while (cursor != null && cursor.moveToNext() && entries.size() < MAX_ROWS * 4) {
                String name = cursor.getString(0);
                String number = cursor.getString(1);
                if (number == null || number.isEmpty()) {
                    continue;
                }
                entries.add(new Entry((name == null ? number : name) + "\n" + number, number));
            }
        }
    }

    private void readCallHistory(List<Entry> entries) {
        String[] columns = {
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE
        };
        SimpleDateFormat format = new SimpleDateFormat("dd MMM, HH:mm", Locale.US);
        try (Cursor cursor = getContentResolver().query(
                CallLog.Calls.CONTENT_URI, columns, null, null, CallLog.Calls.DATE + " DESC")) {
            while (cursor != null && cursor.moveToNext() && entries.size() < MAX_ROWS) {
                String number = cursor.getString(0);
                String name = cursor.getString(1);
                int type = cursor.getInt(2);
                long date = cursor.getLong(3);
                if (number == null) {
                    number = "";
                }
                String who = name != null && !name.isEmpty() ? name + "  " + number
                        : number.isEmpty() ? "Hidden number" : number;
                entries.add(new Entry(
                        who + "\n" + typeLabel(type) + "  " + format.format(new Date(date)),
                        number));
            }
        }
    }

    private static String typeLabel(int type) {
        switch (type) {
            case CallLog.Calls.INCOMING_TYPE:
                return "Incoming";
            case CallLog.Calls.OUTGOING_TYPE:
                return "Outgoing";
            case CallLog.Calls.MISSED_TYPE:
                return "Missed";
            case CallLog.Calls.REJECTED_TYPE:
                return "Declined";
            case CallLog.Calls.BLOCKED_TYPE:
                return "Blocked";
            case CallLog.Calls.VOICEMAIL_TYPE:
                return "Voicemail";
            default:
                return "Call";
        }
    }

    private void openDialPad(String number) {
        startActivity(new Intent(this, MainActivity.class)
                .setAction(Intent.ACTION_DIAL)
                .setData(Uri.fromParts("tel", number, null))
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        finish();
    }
}
