package com.sre.jiraautoack;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Main screen: make this the default phone app, switch auto-acknowledge on for a
 * shift, place a call, open call history and contacts, change the settings, and
 * read the activity log.
 */
public class MainActivity extends Activity {

    static final String VERSION = "1.1";

    private static final int REQUEST_PERMISSIONS = 1;
    private static final int REQUEST_ROLE = 2;

    private TextView statusView;
    private TextView summaryView;
    private TextView logView;
    private Button roleButton;
    private Button fullScreenButton;
    private Switch enabledSwitch;
    private EditText numberEdit;

    private EditText allowEdit;
    private EditText neverEdit;
    private EditText digitsEdit;
    private EditText waitEdit;
    private EditText gapEdit;
    private EditText holdEdit;

    private final CompoundButton.OnCheckedChangeListener switchListener =
            new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton button, boolean checked) {
                    Prefs.setEnabled(MainActivity.this, checked);
                    Prefs.log(MainActivity.this,
                            checked ? "Auto-acknowledge switched ON" : "Auto-acknowledge switched OFF");
                    refresh();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildLayout());
        showSettings();
        requestMissingPermissions();
        fillNumberFrom(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        fillNumberFrom(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    /** Other apps, and this app's own lists, send the number to dial as a tel: address. */
    private void fillNumberFrom(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "tel".equals(data.getScheme())) {
            numberEdit.setText(data.getSchemeSpecificPart());
        }
    }

    private boolean isDefaultPhoneApp() {
        RoleManager roles = getSystemService(RoleManager.class);
        return roles != null && roles.isRoleHeld(RoleManager.ROLE_DIALER);
    }

    private void refresh() {
        boolean isDefault = isDefaultPhoneApp();
        boolean enabled = Prefs.isEnabled(this);

        String status;
        if (!isDefault) {
            status = "NOT ACTIVE. This app is not the default phone app, so it cannot answer calls.";
        } else if (enabled) {
            status = "ACTIVE. Matching calls are answered automatically. All other calls ring normally.";
        } else {
            status = "OFF. Every call rings normally.";
        }
        statusView.setText(status);
        roleButton.setVisibility(isDefault ? View.GONE : View.VISIBLE);
        summaryView.setText(describeSettings());

        enabledSwitch.setOnCheckedChangeListener(null);
        enabledSwitch.setChecked(enabled);
        enabledSwitch.setOnCheckedChangeListener(switchListener);

        boolean fullScreenBlocked = false;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager notifications = getSystemService(NotificationManager.class);
            fullScreenBlocked = notifications != null && !notifications.canUseFullScreenIntent();
        }
        fullScreenButton.setVisibility(fullScreenBlocked ? View.VISIBLE : View.GONE);

        String log = Prefs.getLog(this);
        logView.setText(log.isEmpty() ? "No activity yet." : log);
    }

    /** One sentence that states exactly what will happen, in order. */
    private String describeSettings() {
        String allow = join(AckConfig.splitList(Prefs.getAllowPrefixes(this)));
        String never = join(AckConfig.splitList(Prefs.getNeverPrefixes(this)));
        String digits = Prefs.getDigits(this);
        if (allow.isEmpty()) {
            return "No callers are answered automatically.";
        }
        StringBuilder sb = new StringBuilder("Answers callers starting with ").append(allow);
        for (int i = 0; i < digits.length(); i++) {
            if (i == 0) {
                sb.append(". Key 1: presses ").append(digits.charAt(i)).append(' ')
                        .append(seconds(Prefs.getWaitMs(this))).append(" s after answering");
            } else {
                sb.append(". Key ").append(i + 1).append(": presses ").append(digits.charAt(i))
                        .append(' ').append(seconds(Prefs.getGapMs(this))).append(" s later");
            }
        }
        sb.append(". Hangs up ").append(seconds(Prefs.getHoldMs(this)))
                .append(" s after the last key.");
        if (!never.isEmpty()) {
            sb.append(" Callers starting with ").append(never)
                    .append(" and all other callers ring normally.");
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------------
    // Settings
    // ---------------------------------------------------------------------

    private void showSettings() {
        allowEdit.setText(Prefs.getAllowPrefixes(this));
        neverEdit.setText(Prefs.getNeverPrefixes(this));
        digitsEdit.setText(Prefs.getDigits(this));
        waitEdit.setText(seconds(Prefs.getWaitMs(this)));
        gapEdit.setText(seconds(Prefs.getGapMs(this)));
        holdEdit.setText(seconds(Prefs.getHoldMs(this)));
    }

    private void saveSettings() {
        String allow = allowEdit.getText().toString().trim();
        String never = neverEdit.getText().toString().trim();
        String digits = digitsEdit.getText().toString().trim();
        long wait;
        long gap;
        long hold;
        try {
            wait = parseSeconds(waitEdit.getText().toString());
            gap = parseSeconds(gapEdit.getText().toString());
            hold = parseSeconds(holdEdit.getText().toString());
        } catch (NumberFormatException e) {
            toast("Enter the times as numbers, for example 2 or 0.5");
            return;
        }
        if (!AckConfig.isValidPrefixList(allow) || !AckConfig.isValidPrefixList(never)) {
            toast("Number prefixes must look like +1 or +14155551234, separated by commas");
            return;
        }
        if (!AckConfig.isValidDigits(digits)) {
            toast("Keys can contain only 0-9, * and #");
            return;
        }
        if (wait < 0 || wait > AckConfig.MAX_WAIT_MS || hold < 0 || hold > AckConfig.MAX_WAIT_MS
                || gap < AckConfig.MIN_GAP_MS || gap > AckConfig.MAX_WAIT_MS) {
            toast("Times must be 0 to 60 seconds, with at least 0.5 seconds between keys");
            return;
        }
        Prefs.saveSettings(this, allow, never, digits, wait, gap, hold);
        Prefs.log(this, "Settings saved: keys " + digits + ", first key after " + seconds(wait)
                + " s, " + seconds(gap) + " s between keys");
        toast("Saved");
        showSettings();
        refresh();
    }

    private static long parseSeconds(String text) {
        return Math.round(Double.parseDouble(text.trim()) * 1000);
    }

    private static String seconds(long ms) {
        return ms % 1000 == 0 ? String.valueOf(ms / 1000) : String.valueOf(ms / 1000.0);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    // ---------------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------------

    private void requestDefaultPhoneApp() {
        RoleManager roles = getSystemService(RoleManager.class);
        if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_DIALER)) {
            startActivityForResult(
                    roles.createRequestRoleIntent(RoleManager.ROLE_DIALER), REQUEST_ROLE);
        }
    }

    private void openFullScreenSetting() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException e) {
            toast("Open Settings > Apps > Special app access > Full screen notifications");
        }
    }

    private void openDirectory(String mode) {
        startActivity(new Intent(this, DirectoryActivity.class)
                .putExtra(DirectoryActivity.EXTRA_MODE, mode));
    }

    private void placeCall() {
        String number = numberEdit.getText().toString().trim();
        if (number.isEmpty()) {
            return;
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQUEST_PERMISSIONS);
            return;
        }
        TelecomManager telecom = getSystemService(TelecomManager.class);
        telecom.placeCall(Uri.fromParts("tel", number, null), new Bundle());
    }

    private void requestMissingPermissions() {
        List<String> wanted = new ArrayList<>();
        wanted.add(Manifest.permission.CALL_PHONE);
        wanted.add(Manifest.permission.READ_PHONE_STATE);
        wanted.add(Manifest.permission.READ_CONTACTS);
        wanted.add(Manifest.permission.READ_CALL_LOG);
        if (Build.VERSION.SDK_INT >= 33) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        List<String> missing = new ArrayList<>();
        for (String permission : wanted) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                missing.add(permission);
            }
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        }
    }

    private static String join(String[] values) {
        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(value);
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------------
    // Layout (built in code, so the project has no layout files)
    // ---------------------------------------------------------------------

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));

        root.addView(heading("Status"));
        statusView = text("");
        root.addView(statusView, matchWidth());

        roleButton = button("Set as default phone app", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestDefaultPhoneApp();
            }
        });
        root.addView(roleButton, matchWidth());

        fullScreenButton = button("Allow the call screen on the lock screen",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openFullScreenSetting();
                    }
                });
        root.addView(fullScreenButton, matchWidth());

        root.addView(heading("Shift"));
        enabledSwitch = new Switch(this);
        enabledSwitch.setText("Auto-acknowledge (switch on for your shift)");
        enabledSwitch.setTextSize(16);
        root.addView(enabledSwitch, matchWidth());
        summaryView = text("");
        root.addView(summaryView, matchWidth());

        root.addView(heading("Make a call"));
        numberEdit = new EditText(this);
        numberEdit.setHint("Phone number");
        numberEdit.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(numberEdit, matchWidth());
        root.addView(button("Call", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeCall();
            }
        }), matchWidth());

        LinearLayout lists = new LinearLayout(this);
        lists.setOrientation(LinearLayout.HORIZONTAL);
        lists.addView(button("Call history", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDirectory(DirectoryActivity.MODE_RECENTS);
            }
        }), weighted());
        lists.addView(button("Contacts", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDirectory(DirectoryActivity.MODE_CONTACTS);
            }
        }), weighted());
        root.addView(lists, matchWidth());

        root.addView(heading("Settings"));
        int decimal = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;
        allowEdit = field(root, "Answer callers whose number starts with",
                InputType.TYPE_CLASS_TEXT);
        neverEdit = field(root, "Never answer callers whose number starts with",
                InputType.TYPE_CLASS_TEXT);
        digitsEdit = field(root, "Keys to press, in order (first key first)",
                InputType.TYPE_CLASS_PHONE);
        waitEdit = field(root, "Seconds after answering before the first key", decimal);
        gapEdit = field(root, "Seconds between one key and the next", decimal);
        holdEdit = field(root, "Seconds on the line after the last key", decimal);
        root.addView(button("Save settings", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        }), matchWidth());

        root.addView(heading("Activity log (newest line at the top)"));
        logView = text("");
        logView.setTextIsSelectable(true);
        root.addView(logView, matchWidth());
        root.addView(button("Clear log", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.clearLog(MainActivity.this);
                refresh();
            }
        }), matchWidth());

        TextView version = text("Jira Auto Ack version " + VERSION);
        version.setPadding(0, dp(20), 0, 0);
        root.addView(version, matchWidth());

        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    /** Adds a small label and an input box, and returns the input box. */
    private EditText field(LinearLayout root, String label, int inputType) {
        TextView labelView = text(label);
        labelView.setPadding(0, dp(10), 0, 0);
        root.addView(labelView, matchWidth());
        EditText edit = new EditText(this);
        edit.setInputType(inputType);
        edit.setSingleLine(true);
        root.addView(edit, matchWidth());
        return edit;
    }

    private TextView heading(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(20);
        view.setPadding(0, dp(20), 0, dp(6));
        return view;
    }

    private TextView text(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(15);
        return view;
    }

    private Button button(String value, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
