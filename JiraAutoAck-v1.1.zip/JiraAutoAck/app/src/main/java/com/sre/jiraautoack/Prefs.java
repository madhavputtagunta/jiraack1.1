package com.sre.jiraautoack;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Stores the on-shift switch, the settings and a short activity log. */
final class Prefs {

    private static final String FILE = "jira_auto_ack";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_LOG = "log";
    private static final String KEY_ALLOW = "allow_prefixes";
    private static final String KEY_NEVER = "never_prefixes";
    private static final String KEY_DIGITS = "digits";
    private static final String KEY_WAIT = "wait_ms";
    private static final String KEY_GAP = "gap_ms";
    private static final String KEY_HOLD = "hold_ms";
    private static final int MAX_LOG_LINES = 50;

    private Prefs() {
    }

    private static SharedPreferences sp(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Off by default, so nothing is auto-answered until you switch it on. */
    static boolean isEnabled(Context context) {
        return sp(context).getBoolean(KEY_ENABLED, false);
    }

    static void setEnabled(Context context, boolean enabled) {
        sp(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    static String getAllowPrefixes(Context context) {
        return sp(context).getString(KEY_ALLOW, AckConfig.DEFAULT_AUTO_ACK_PREFIXES);
    }

    static String getNeverPrefixes(Context context) {
        return sp(context).getString(KEY_NEVER, AckConfig.DEFAULT_NEVER_ACK_PREFIXES);
    }

    static String getDigits(Context context) {
        return sp(context).getString(KEY_DIGITS, AckConfig.DEFAULT_DIGITS);
    }

    static long getWaitMs(Context context) {
        return sp(context).getLong(KEY_WAIT, AckConfig.DEFAULT_WAIT_BEFORE_FIRST_KEY_MS);
    }

    static long getGapMs(Context context) {
        return sp(context).getLong(KEY_GAP, AckConfig.DEFAULT_GAP_BETWEEN_KEYS_MS);
    }

    static long getHoldMs(Context context) {
        return sp(context).getLong(KEY_HOLD, AckConfig.DEFAULT_HOLD_AFTER_KEYS_MS);
    }

    static void saveSettings(Context context, String allow, String never, String digits,
            long waitMs, long gapMs, long holdMs) {
        sp(context).edit()
                .putString(KEY_ALLOW, allow)
                .putString(KEY_NEVER, never)
                .putString(KEY_DIGITS, digits)
                .putLong(KEY_WAIT, waitMs)
                .putLong(KEY_GAP, gapMs)
                .putLong(KEY_HOLD, holdMs)
                .apply();
    }

    /** Adds a line to the top of the log and keeps the newest 50 lines. */
    static synchronized void log(Context context, String message) {
        Log.i("JiraAutoAck", message);
        String stamp = new SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(new Date());
        String old = sp(context).getString(KEY_LOG, "");
        String[] lines = old.isEmpty() ? new String[0] : old.split("\n");
        StringBuilder sb = new StringBuilder(stamp).append("  ").append(message);
        for (int i = 0; i < lines.length && i < MAX_LOG_LINES - 1; i++) {
            sb.append('\n').append(lines[i]);
        }
        sp(context).edit().putString(KEY_LOG, sb.toString()).apply();
    }

    static String getLog(Context context) {
        return sp(context).getString(KEY_LOG, "");
    }

    static void clearLog(Context context) {
        sp(context).edit().remove(KEY_LOG).apply();
    }
}
